#! /usr/bin/env python3
from fenetre import *


if __name__ == "__main__":
    root = Tk()

    interface = Interface(master=root)
    interface.master.title("Projet Python 2014")
    #interface.master.title("The Master")
    interface.pack(fill="both", expand=True)
    interface.mainloop()